package com.hyuk.datareader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataReaderApplicationTests {

    @Test
    void contextLoads() {
    }

}
