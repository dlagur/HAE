package com.hyuk.datareader;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import lombok.RequiredArgsConstructor;
import org.bson.Document;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;

//싱글톤 패턴의 인스턴스를 자동 생성해주는 어노테이션 --> 서비스 역할과 동일
@Component
@RequiredArgsConstructor
public class StartListener implements ApplicationListener<ApplicationStartedEvent> {
    private final BookRespository bookRespository;

    @Override
    //Application이 시작하면 한번만 호출되는 메서드
    public void onApplicationEvent(ApplicationStartedEvent event) {
        //MySQL의 데이터를 가져오기
        List<Book> Books = bookRespository.findAll();
        //MongoDB 연결
        //build, create와 같은 메서드
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase mongoDatabase = mongoClient.getDatabase("springcqrs");
        MongoCollection<org.bson.Document> mongo_books = mongoDatabase.getCollection("books");

        mongo_books.drop();
        mongo_books = mongoDatabase.getCollection("books");

        //data 복사
        for(Book book : Books) {
            Document mongoBook = new Document();
            mongoBook.append("bid", book.getBid());
            mongoBook.append("title", book.getTitle());
            mongoBook.append("author", book.getAuthor());
            mongoBook.append("category", book.getCategory());
            mongoBook.append("published_date", book.getPublished_Date());
            mongoBook.append("pages", book.getPages());
            mongoBook.append("price", book.getPrice());
            mongoBook.append("description", book.getDescription());

            mongo_books.insertOne(mongoBook);
        }
    }
}
