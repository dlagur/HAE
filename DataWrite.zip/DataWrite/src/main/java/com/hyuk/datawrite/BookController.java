package com.hyuk.datawrite;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class BookController {
    private final BookService bookService;

    // form-data 대신 body(raw : JSON 형태)를 사용하거나
    // RequestParam을 생성한다
    @PostMapping("/cqrs/book")
    public String saveBook(@RequestBody BookDTO bookDTO) {
        bookService.saveBook(bookDTO);
        return "성공";
    }

}
