package com.hyuk.datawrite;
// Domain Model(Entity) 객체를 그대로 두고 복사하여, 다양한 Presentation Logic을 추가한 정도로
//사용하며 Entity는 Persistent만을 위해서 사용한다.
import lombok.Data;

@Data
public class BookDTO {
    private Long bid;
    private String title;
    private String author;
    private String category;
    private int pages;
    private int price;
    private String published_date;
    private String description;
}
