package com.hyuk.datawrite;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;


@Service
@RequiredArgsConstructor
//Django에서 views.py 역할
public class BookService {
  private final BookRepository bookRepository;
    private final KafkaProducer kafkaProducer;

    //데이터 저장
  //파라미터를 받아서 엔터티를 생성하고 repository를 이용해서 삽입
  public void saveBook(BookDTO bookDTO) {
      try {
          SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
          java.util.Date utilDate = simpleDateFormat.parse(bookDTO.getPublished_date());
          java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

          // 빌더 패턴을 이용한 Entity 생성
          //Book book = new Book();
          Book book = Book.builder().
                  title(bookDTO.getTitle()).
                  author(bookDTO.getAuthor()).
                  category(bookDTO.getCategory()).
                  pages(bookDTO.getPages()).
                  price(bookDTO.getPrice()).
                  published_Date(sqlDate).
                  description(bookDTO.getDescription()).
                  build();
          //데이터베이스에 데이터 삽입
          bookRepository.save(book);
          //Kafka에 메시지 전송
          bookDTO.setBid(book.getBid());
          kafkaProducer.sendMessage(bookDTO);
      }

      //ParseException 처리를 강제합니다.
      catch (ParseException e) {
          System.out.println(e);
      }
  }
}
